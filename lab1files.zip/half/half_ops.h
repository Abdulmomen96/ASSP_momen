#include "half_float.h"

HALF mulh(HALF i1, HALF i2);
HALF addh(HALF i1, HALF i2);
HALF subh(HALF i1, HALF i2);




#include <stdio.h>

int sample_read(FILE *f);
void sample_write(FILE *f, int dval);
void sample_copy(FILE *out, FILE *in, int length);


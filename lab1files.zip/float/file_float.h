#include <stdio.h>
#include <math.h>

float sample_read(FILE *f);
void sample_write(FILE *f, float dval);
void sample_copy(FILE *out, FILE *in, int length);

